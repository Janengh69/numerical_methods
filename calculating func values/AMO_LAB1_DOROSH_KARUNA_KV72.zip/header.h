#include <iostream>
#include <cmath>
#include <iomanip>

#define a -13.9
#define b 1.4
#define table_len 4

using namespace std;

double Rn_calc(double eps, int& n, double& x, double& result);


